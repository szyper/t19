﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9_1_klasy.classes
{
    internal class Student
    {
        public string StudentNumber { get; set; }
    }
}
